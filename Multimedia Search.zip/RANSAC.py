# -*- coding: utf-8 -*-
"""
Created on Sat Nov 16 09:07:18 2019

@author: meta
"""

#!/usr/local/bin/python2.7
#python search.py -i dataset/testing/all_souls_000000.jpg

import argparse as ap
import cv2
import imutils 
import numpy as np
import os
from sklearn.externals import joblib
from scipy.cluster.vq import *
from matplotlib import pyplot as plt

from sklearn import preprocessing
import numpy as np

from pylab import *
from PIL import Image
from rootsift import RootSIFT


def ransac (img1,img2):
    MIN_MATCH_COUNT = 10
    # Initiate SIFT detector
    sift = cv2.xfeatures2d.SIFT_create()

    # find the keypoints and descriptors with SIFT
    kp1, des1 = sift.detectAndCompute(img1,None)
    kp2, des2 = sift.detectAndCompute(img2,None)

    FLANN_INDEX_KDTREE = 0
    index_params = dict(algorithm = FLANN_INDEX_KDTREE, trees = 5)
    search_params = dict(checks = 50)

    flann = cv2.FlannBasedMatcher(index_params, search_params)

    matches = flann.knnMatch(des1,des2,k=2)

    # store all the good matches as per Lowe's ratio test.
    good = []
    for m,n in matches:
        if m.distance < 0.7*n.distance:
            good.append(m)
            
    if len(good)>MIN_MATCH_COUNT: # 获取关键点的坐标
        src_pts = np.float32([ kp1[m.queryIdx].pt for m in good ]).reshape(-1,1,2)
        dst_pts = np.float32([ kp2[m.trainIdx].pt for m in good ]).reshape(-1,1,2)
        
        M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC,5.0)
        matchesMask = mask.ravel().tolist()
    else:
        print("Not enough matches are found - %d/%d" % (len(good),MIN_MATCH_COUNT))
        matchesMask = None


        
    draw_params = dict(matchColor = (0,255,0), # draw matches in green color
                   singlePointColor = (0,255,0),
                   matchesMask = matchesMask, # draw only inliers
                   flags = 2)

    img0 = cv2.drawMatches(img1,kp1,img2,kp2,good,None,**draw_params)
    return img0

def main():
    # Get the path of the training set
    parser = ap.ArgumentParser()
    parser.add_argument("-i", "--image", help="Path to query image", required="True")
    args = vars(parser.parse_args())
    
    # Get query image path
    image_path = args["image"]
    
    # Load the classifier, class names, scaler, number of clusters and vocabulary 
    im_features, image_paths, idf, numWords, voc = joblib.load("bag-of-words.pkl")
        
    fea_det = cv2.xfeatures2d.SIFT_create()
    
    # List where all the descriptors are stored
    des_list = []
    
    im = cv2.imread(image_path)
    im_size = im.shape
    # print str(im.shape)
    im = cv2.resize(im,(im_size[1]/4,im_size[0]/4))
    
    
    # kpts = fea_det.detect(im)
    # kpts, des = des_ext.compute(im, kpts)
    kpts, des = fea_det.detectAndCompute(im, None)
    
    des_list.append((image_path, des))   
        
    # Stack all the descriptors vertically in a numpy array
    descriptors = des_list[0][1]
    
    # 
    test_features = np.zeros((1, numWords), "float32")
    words, distance = vq(descriptors,voc)
    for w in words:
        test_features[0][w] += 1
    
    # Perform Tf-Idf vectorization and L2 normalization
    test_features = test_features*idf
    test_features = preprocessing.normalize(test_features, norm='l2')
    
    score = np.dot(test_features, im_features.T)
    rank_ID = np.argsort(-score)
    
    figure()
    gray()
    subplot(5,2,1)
    imshow(im[:,:,::-1])
    axis('off')

    
    for i, ID in enumerate(rank_ID[0][0:8]):
    	img = cv2.imread(image_paths[ID])
        ransac_img = ransac(im,img)
    	gray()
    	subplot(5,2,i+3)
    	imshow(ransac_img)
    	axis('off')
    show()

if __name__ == '__main__':
    main()
    




