# -*- coding: utf-8 -*-
"""
Created on Sat Nov 16 20:04:07 2019

@author: meta
"""

#!/usr/local/bin/python2.7
#python findFeatures.py -t dataset/training/

import argparse as ap
import cv2
import numpy as np
import os
from sklearn.externals import joblib
from scipy.cluster.vq import *
import scipy.cluster.hierarchy as sch
import matplotlib.pylab as plt

from sklearn import preprocessing
from rootsift import RootSIFT
import math

# Get the path of the training set
parser = ap.ArgumentParser()
parser.add_argument("-t", "--trainingSet", help="Path to Training Set", required="True")
args = vars(parser.parse_args())

# Get the training classes names and store them in a list
train_path = args["trainingSet"]
#train_path = "dataset/training/"

training_names = os.listdir(train_path)
max_cluster = 500

# Get all the path to the images and save them in a list
# image_paths and the corresponding label in image_paths
image_paths = []
for training_name in training_names:
    image_path = os.path.join(train_path, training_name)
    image_paths += [image_path]

# Create feature extraction and keypoint detector objects
# fea_det = cv2.FeatureDetector_create("SIFT")
# des_ext = cv2.DescriptorExtractor_create("SIFT")
fea_det = cv2.xfeatures2d.SIFT_create()

# List where all the descriptors are stored
des_list = []

for i, image_path in enumerate(image_paths):
    im = cv2.imread(image_path)
    im_size = im.shape

    # print str(im.shape)
    # if im_size[1] > im_size[0]:
    #     im = cv2.resize(im,(imagesize_0,imagesize_1))
    # else:
    #     im = cv2.resize(im,(imagesize_1,imagesize_0))
    # print str(im.shape)

    im = cv2.resize(im,(im_size[1]/4,im_size[0]/4))

    print "Extract SIFT of %s image, %d of %d images" %(training_names[i], i, len(image_paths))
    # kpts = fea_det.detect(im)
    # kpts, des = des_ext.compute(im, kpts)
    kpts, des = fea_det.detectAndCompute(im, None)
    # rootsift
    #rs = RootSIFT()
    #des = rs.compute(kpts, des)
    des_list.append((image_path, des))
    # print str(des.shape)  
    
# Stack all the descriptors vertically in a numpy array
downsampling = 2
descriptors = des_list[0][1][::downsampling,:]
for image_path, descriptor in des_list[1:]:
    # print np.size(descriptor)
    # print image_path
    # print descriptor
    descriptors = np.vstack((descriptors, descriptor[::downsampling,:]))

# Stack all the descriptors vertically in a numpy array
# descriptors = des_list[0][1]
# for image_path, descriptor in des_list[1:]:
#     print np.size(descriptor)
#     print descriptor
#     # if np.size(descriptor) != 0:
#     descriptors = np.vstack((descriptors, descriptor))  

# Perform hierarchical clustering
#生成点与点之间的距离矩阵,这里用的欧氏距离:
disMat = sch.distance.pdist(descriptors,'euclidean')
#进行层次聚类:
Z = sch.linkage(disMat,method='average')
#将层级聚类结果以树状图表示出来并保存为plot_dendrogram.png
P=sch.dendrogram(Z)
plt.savefig('plot_dendrogram.png')
#根据linkage matrix z得到聚类结果:
labels = sch.fcluster(Z, t=max_cluster, criterion="maxclust")

print "Start hierarchical clustering: %d words, %d key points" %(max_cluster, descriptors.shape[0])
# 将sift特征按照聚类结果分类存放
classfied_des_num = {}
for i in range(len(labels)):
    label = labels[i]
    if label in classfied_des_num:
        classfied_des_num[label].append(i)
    else:
        classfied_des_num[label] = [i]

centroids = []
# 计算每一类的类中心
for label in classfied_des_num.keys():
    indexes = classfied_des_num[label]
    a = descriptors[indexes[0]]
    for i in range(len(indexes)):
        a += descriptors[indexes[i]]
    a = a / len(indexes)
    centroids.append(a)
centroids = np.array(centroids)
voc = centroids
# Calculate the histogram of features
im_features = np.zeros((len(image_paths), max_cluster), "float32")
for i in xrange(len(image_paths)):
    words, distance = vq(des_list[i][1],voc)
    for w in words:
        im_features[i][w] += 1

# Perform Tf-Idf vectorization
nbr_occurences = np.sum( (im_features > 0) * 1, axis = 0)
idf = np.array(np.log((1.0*len(image_paths)+1) / (1.0*nbr_occurences + 1)), 'float32')

# Perform L2 normalization
im_features = im_features*idf
im_features = preprocessing.normalize(im_features, norm='l2')

joblib.dump((im_features, image_paths, idf, max_cluster, voc), "bag-of-words1.pkl", compress=3)  
