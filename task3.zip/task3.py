import numpy as np
import sys
from scipy import special
import matplotlib.pyplot as plt 
sys.path.append('mnist')
import mnist

def load_data():
    train_images = mnist.train_images()
    train_labels = mnist.train_labels()
    
    test_images = mnist.test_images()
    test_labels = mnist.test_labels()
    
    n_train, w, h = train_images.shape
    X_train = train_images.reshape( (n_train, w*h) )
    Y_train = train_labels
    
    n_test, w, h = test_images.shape
    X_test = test_images.reshape( (n_test, w*h) )
    Y_test = test_labels
    
    print(X_train.shape, Y_train.shape)
    print(X_test.shape, Y_test.shape)
    
    return X_train, Y_train, X_test, Y_test

def initModel(in_num, layer1_num, layer2_num, layer3_num, layer4_num, out_num):
    model = dict(W1=np.random.randn(in_num, layer1_num)/np.sqrt(in_num/2), 
                 b1=np.random.randn(1, layer1_num),
                 W2=np.random.randn(layer1_num, layer2_num)/np.sqrt(layer1_num/2),
                 b2=np.random.randn(1, layer2_num),
                 W3=np.random.randn(layer2_num, layer3_num)/np.sqrt(layer2_num/2),
                 b3=np.random.randn(1, layer3_num),
                 W4=np.random.randn(layer3_num, layer4_num)/np.sqrt(layer3_num/2),
                 b4=np.random.randn(1, layer4_num),
                 W5=np.random.randn(layer4_num, out_num)/np.sqrt(layer4_num/2),
                 b5=np.random.randn(1, out_num))
    return model

def reluPrime(z):
    z = np.where(z>0, 1, 0)
    return z

def relu(z):
    z = (np.abs(z)+z)/2.0
    return z

def predict(model, x):
    W1, b1, W2, b2, W3, b3, W4, b4, W5, b5 = model['W1'], model['b1'], model['W2'], model['b2'], model['W3'], model['b3'], model['W4'], model['b4'], model['W5'], model['b5']
    z1 = x.dot(W1) + b1
    a1 = np.tanh(z1)
    #a1 = relu(z1)
    z2 = a1.dot(W2) + b2
    a2 = np.tanh(z2)
    #a2 = relu(z2)
    z3 = a2.dot(W3) + b3
    a3 = np.tanh(z3)
    #a3 = relu(z3)
    z4 = a3.dot(W4) + b4
    a4 = np.tanh(z4)
    #a4 = relu(z4)
    z5 = a4.dot(W5) + b5
    #exp_scores = np.exp(z2)
    #probs = exp_scores / np.sum(exp_scores, axis=1, keepdims=True)
    probs = special.softmax(z5, axis=1)
    return np.argmax(probs, axis=1)

def training(model, x, y, num_passes=100, reg_lambda=0.001, epsilon=0.00001):
    num_examples = x.shape[0]
    loss_all = []
    for i in range(num_passes):
        W1, b1, W2, b2, W3, b3, W4, b4, W5, b5 = model['W1'], model['b1'], model['W2'], model['b2'], model['W3'], model['b3'], model['W4'], model['b4'], model['W5'], model['b5']
        z1 = x.dot(W1) + b1
        a1 = np.tanh(z1)
        #a1 = relu(z1)
        z2 = a1.dot(W2) + b2
        a2 = np.tanh(z2)
        #a2 = relu(z2)
        z3 = a2.dot(W3) + b3
        a3 = np.tanh(z3)
        #a3 = relu(z3)
        z4 = a3.dot(W4) + b4
        a4 = np.tanh(z4)
        #a4 = relu(z4)
        z5 = a4.dot(W5) + b5
        #exp_scores = np.exp(z2)
        #probs = exp_scores / np.sum(exp_scores, axis=1, keepdims=True)
        probs = special.softmax(z5, axis=1)
        
        loss = np.sum(special.logsumexp(z5, axis=1) - z5[range(z5.shape[0]), y], axis=0) / z5.shape[0]
        loss_all.append(loss)
    
        #Backpropagation
        delta6 = probs
        delta6[range(num_examples), y] -= 1
        dW5 = (a4.T).dot(delta6)
        db5 = np.sum(delta6, axis=0, keepdims=True)
        
        delta5 = delta6.dot(W5.T) * (1-np.power(a4, 2))
        #delta5 = delta6.dot(W5.T) * reluPrime(a4)
        dW4 = np.dot(a3.T, delta5)
        db4 = np.sum(delta5, axis=0)
        
        delta4 = delta5.dot(W4.T) * (1-np.power(a3, 2))
        #delta4 = delta5.dot(W4.T) * reluPrime(a3)
        dW3 = np.dot(a2.T, delta4)
        db3 = np.sum(delta4, axis=0)
        
        delta3 = delta4.dot(W3.T) * (1-np.power(a2, 2))
        #delta3 = delta4.dot(W3.T) * reluPrime(a2)
        dW2 = np.dot(a1.T, delta3)
        db2 = np.sum(delta3, axis=0)
        
        delta2 = delta3.dot(W2.T) * (1-np.power(a1, 2))
        #delta2 = delta3.dot(W2.T) * reluPrime(a1)
        dW1 = np.dot(x.T, delta2)
        db1 = np.sum(delta2, axis=0)

        dW5 += reg_lambda * W5
        dW4 += reg_lambda * W4
        dW3 += reg_lambda * W3
        dW2 += reg_lambda * W2
        dW1 += reg_lambda * W1
        
        W1 += -epsilon * dW1
        b1 += -epsilon * db1
        W2 += -epsilon * dW2
        b2 += -epsilon * db2
        W3 += -epsilon * dW3
        b3 += -epsilon * db3
        W4 += -epsilon * dW4
        b4 += -epsilon * db4
        W5 += -epsilon * dW5
        b5 += -epsilon * db5
        
        model['W1'], model['b1'], model['W2'], model['b2'], model['W3'], model['b3'], model['W4'], model['b4'], model['W5'], model['b5'] = W1, b1, W2, b2, W3, b3, W4, b4, W5, b5       

    return model, loss_all

def main():
    train_images = mnist.train_images()
    train_labels = mnist.train_labels()

    test_images = mnist.test_images()
    test_labels = mnist.test_labels()

    n_train, w, h = train_images.shape
    X_train = train_images.reshape((n_train, w * h))
    Y_train = train_labels

    n_test, w, h = test_images.shape
    X_test = test_images.reshape((n_test, w * h))
    Y_test = test_labels
    
    model = initModel(784,100,80,60,30,10)
    model, loss_all = training(model, X_train, Y_train)
    y_predict = predict(model, X_test)
    accuracy = 0
    for i in range(len(y_predict)):
        if y_predict[i] == Y_test[i]:
            accuracy += 1
    print('The accuracy is ', accuracy/len(y_predict))
    print(y_predict)
    plt.title("training error curves")
    plt.xlabel("epochs")
    plt.ylabel("loss")
    plt.plot(loss_all)
    plt.show()

if __name__ == '__main__':
    main()