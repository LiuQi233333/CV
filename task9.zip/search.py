import cv2
from sklearn.externals import joblib
from scipy.cluster.vq import *
from sklearn import preprocessing
from pylab import *
from matplotlib import pyplot as plt
from PIL import Image
import os

def search(image_path):

    # Load the classifier, class names, scaler, number of clusters and vocabulary
    im_features, image_paths, idf, numWords, voc = joblib.load("bof.pkl")

    # Create feature extraction and keypoint detector objects

    fea_det = cv2.xfeatures2d.SIFT_create(600)
    # List where all the descriptors are stored
    des_list = []

    im = cv2.imread(image_path)
    kpts = fea_det.detect(im)

    kpts, des = fea_det.detectAndCompute(im, None)

    des_list.append((image_path, des))

    # Stack all the descriptors vertically in a numpy array
    descriptors = des_list[0][1]

    #
    test_features = np.zeros((1, numWords), "float32")
    words, distance = vq(descriptors, voc)
    for w in words:
        test_features[0][w] += 1

    # Perform Tf-Idf vectorization and L2 normalization
    test_features = test_features * idf
    test_features = preprocessing.normalize(test_features, norm='l2')

    score = np.dot(test_features, im_features.T)
    rank_ID = np.argsort(-score)
    best = image_paths[rank_ID[0][1]]
    return best

#计算正确率
def acc():
    train_path = "logo_dataset"
    training_names = os.listdir(train_path)
    image_paths = []
    count = 0
    for training_name in training_names:
        image_path = os.path.join(train_path, training_name)
        image_paths += [image_path]
    for path in image_paths:
        print(path)
        label = path.split("_")[5:]
        label = "_".join(label)
        label = label.split('-')[:-1]
        label = "_".join(label)
        best = search(path)

        slabel = best.split("_")[5:]
        slabel = "_".join(slabel)
        slabel = slabel.split('-')[:-1]
        slabel = "_".join(slabel)
        print(label,'--',slabel)
        if label == slabel:
            count+=1
            print(count)
    return count/len(training_names)
#展示原图和最佳匹配
image_path = './logo_dataset/310100_07_01_01_16777233_63056_61517-5 (Small).jpg'
best = search(image_path)
img = Image.open(image_path)
img_t = Image.open(best)
img_label=image_path.split("/")[-1].split('-')[0]
img_t_label=best.split("\\")[-1].split('-')[0]

plt.subplot(1,2,1),plt.imshow(img)
plt.title(img_label), plt.xticks([]), plt.yticks([])
plt.subplot(1,2,2),plt.imshow(img_t)
plt.title(img_t_label), plt.xticks([]), plt.yticks([])
show()


#展示多张图片

#plt.figure()
#plt.gray()
#plt.subplot(5, 4, 1)
#plt.imshow(im[:, :, ::-1])
#plt.axis('off')
#for i, ID in enumerate(rank_ID[0][0:16]):
#    img = plt.imread(image_paths[ID])
#    plt.gray()
#    plt.subplot(5, 4, i + 5)
#    plt.imshow(img)
#    plt.axis('off')
#plt.show()

if __name__ == '__main__':
    acc = acc()
    print(acc)